package Session_8;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

/**Write a program to convert string date "12/30/2022" to LocalDate format and then convert the same local date to dd-MM-yyyy format. 
 * output: 30-12-2022***/

public class DateFormat2 {
	
	public static void main(String[] args) {
		

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		
		String date = "12/30/2022";
		

		  //convert String to LocalDate
		  LocalDate localDate = LocalDate.parse(date, formatter);
		  System.out.println("localDate "+localDate);
		  
		  Date date1 = java.sql.Date.valueOf(localDate);
		  
		  SimpleDateFormat targetDateFormat = new SimpleDateFormat("dd-MM-yyyy");
		    System.out.println(targetDateFormat.format(date1));


	
	 
	}
}
