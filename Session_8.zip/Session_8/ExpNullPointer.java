package Session_8;


/**Write a program to handle null pointer exception and print the exception message on the console.**/

public class ExpNullPointer{
	
	static String schoolname;

	
	    public static void main (String[] args) {
	    	

			try{
				schoolname.equals("cambridge");
				System.out.println(schoolname);
			}
			catch(NullPointerException e){
				System.out.println("Null Pointer Exception - Test case failed");
			}		
			finally
			{
				System.out.println("I am out");
			}
			}

	    }
	    



