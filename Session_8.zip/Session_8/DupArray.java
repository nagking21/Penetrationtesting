package Session_8;
/**Write a program to display duplicate numbers from the given array. int[] arr={5,3,4,1,4,5,6,7} **/

public class DupArray {
	
	public static void main(String[] args) {
		
		int[] arr0 = {5,3,4,1,4,5,6,7};
		
		for(int i = 0;i<arr0.length;i++) {
			for(int j=i+1;j<arr0.length;j++){
				if(arr0[i]==arr0[j])
					System.out.println(arr0[j]);
			}
		}
		
	}

}
