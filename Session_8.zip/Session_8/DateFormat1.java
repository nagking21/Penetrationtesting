package Session_8;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;



/**Write a program to display current date in MM-dd-yyyy, dd-MM-yyyy and yyyy-MM-dd formats.**/

public class DateFormat1 {
	
	public static void main(String[] args) {
		
		LocalDate myObj = LocalDate.now();
		
		System.out.println(myObj);
		
		Date date = new Date();
		
		SimpleDateFormat MyFormatObj = new SimpleDateFormat("MM-dd-yyyy");
		
		String str = MyFormatObj.format(date);
		
		System.out.println("Formatted date is: "+str);
		
		Date date1 = new Date();
		
		SimpleDateFormat MyFormatObj1 = new SimpleDateFormat("dd-mm-yyyy");
		
         String str1 = MyFormatObj1.format(date1);
		
		System.out.println("Formatted date2 is: "+str1);
		
		Date date2 = new Date();
		
		SimpleDateFormat MyFormatObj2 = new SimpleDateFormat("yyyy-MM-dd");
		
		 String str2 = MyFormatObj2.format(date2);
		 
			System.out.println("Formatted date2 is: "+str2);
			


		
		
		
	}
	
	

}
