package Session_8;
/**Write a program to delete the string "ava" from the string "Java Training" using StringBuffer and StringBuilder. **/
public class StringBufBulddel {
	
	public static void main(String[] args) {
		
	
	       StringBuffer str1 = new StringBuffer("JavaTraining");
	       System.out.println("string buffer before delete is:"+str1);
	       
	       str1.delete(1,4);
	       System.out.println("string buffer after delete is:"+str1);
	       
	       
	       StringBuilder str2 = new StringBuilder("JavaTraining");
	       System.out.println("String buider before delete is:"+str2);
	       
	       str2.delete(1, 4);

	       System.out.println("string builder after delete is:"+str2);
	}

}
