package Session_8;

import java.util.Arrays;

/**Write a program to sort the integer elements in descending order.**/

public class ArrayDescOrder {
	
	public static void main(String[] args) {
		
		int[] arr0 = {4,1,3,5,2};
		int j = arr0.length;
		System.out.println(j);
		
		
		Arrays.sort(arr0);
		
		for(int i=0;i<arr0.length;i++){
			
			System.out.println("descending order of array is:"+arr0[i]);
			
		}
		
		for (int i = 0; i < arr0.length; i++) {     
			
			for(int j1=i+1;j1<arr0.length;j1++){
				
				  if(arr0[i] < arr0[j1]) {    
	                   j1 = arr0[i];    
	                   arr0[i] = arr0[j1];    
	                   arr0[j1] = j1;    
	               }     
				  
				  for (int i1 = 0; i1 < arr0.length; i1++) {     
			            System.out.print(arr0[i1] + " ");    
			        }    
			
			
			
		}
		
	}
	
	}

}
