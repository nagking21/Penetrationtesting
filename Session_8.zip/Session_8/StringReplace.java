package Session_8;
/**Write a program to replace the string "Selenium" in place of "Java". String str="Java Training" output: Selenium Training
**/
public class StringReplace {
	
	
	public static void main(String[] args) {
		
		String str = "Java Training";
		
		String Str1 = "";
		
		System.out.println("string before replace " +str);
		
		Str1 = str.replace("Java", "Selenium");
		
		System.out.println("string after replace " +Str1);
		
	}
	
	

}
