package Session_8;
/**Write a program to join two strings.**/

public class StringJoin {

	public static void main(String[] args) {
		
		String date = String.join("/","26","06","2018");
		System.out.print(date);
		String time = String.join(":", "12","10","10");
		System.out.println(" "+time);

	}

}
