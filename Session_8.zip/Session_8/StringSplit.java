package Session_8;
/**Write a program to split the given string and print the last splitted value on the console.
String dob="01/25/1990"; output: 1990**/

public class StringSplit {
	
	public static void main(String[] args) {
		
		String dob = "01/25/1990";
		
		String arrOfdob = dob.substring (6,10);
		
			System.out.println(arrOfdob);
	}

}
