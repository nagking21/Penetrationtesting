package Session_8;
/**Write a program to handle multiple exceptions in single catch block and print the exception message in all possible ways on 
  the console.**/

public class MulExceptions {
	
	public static void main(String[] args) {
		
		try {
		      int array[] = new int[10];
		      array[10] = 30 / 0;
		    } catch (ArithmeticException e) {
		      System.out.println(e.getMessage());
		    } catch (ArrayIndexOutOfBoundsException e) {
		      System.out.println(e.getMessage());
		    } 
		  }
		
	}


