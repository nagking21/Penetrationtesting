package Session_8;
/**Write a program to handle exception using throws keyword.**/
public class ThrowsException {
	
	static void fun() throws IllegalAccessException
    {
        System.out.println("Inside function(). ");
        throw new IllegalAccessException("demo");
    }
    public static void main(String args[])
    {
        try
        {
            fun();
        }
        catch(IllegalAccessException e)
        {
            System.out.println("caught in main.");
        }
    }
}


