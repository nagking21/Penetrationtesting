package Session_8;

import java.util.Arrays;

/**Write a program to sort the integer elements in reverse order.**/

public class SortArray {
	
	public static void main(String[] args) {
		
		int[] arr0 = {4,1,3,5,2};
		int j = arr0.length;
		System.out.println(j);
		//Arrays.sort(arr0);
		
//		 for (int i = arr0.length; i >=0;i--){
//		       System.out.print(arr0[i]);
//		
//}
		 for (int i = j-1; i >=0;i--){
		       System.out.print(arr0[i]);
		
}
	}
}
