package Session_8;
/**Write a program to compare two string values.**/

public class StringCompare {
	
	public static void main(String[] args) {
		
		String s1 = new String("test");
	    String s2 = new String("JavaTopics");
	    String s3 = new String("selenium");
	    String s4 = new String("test");

	    // Calling equals() method
	    // when strings are equal
	    boolean result = s1.equals(s4);
	    System.out.println(s1 + " and " + s4  + "  are  " + " equal " + "\t" + result);

	    // when strings are not equal
	    result = s1.equals(s3);
	    System.out.println(s1 + " and " + s3 + ": " + result);

	    // when one string is subset of other
	    result = s1.equals(s2);
	    System.out.println(s1 + " and " + s2 + ": " + result);		
		
		
	}

}
