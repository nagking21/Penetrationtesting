package Session_8;
/**Write a program to display the given string in reverse order in all possible ways.
String str="XTGLOBAL";**/

public class StringReverse {
	
	public static void main(String[] args) {
		
		String str = "XTGLOBAL";
		String strrev = "";
		char ch;
	
	
	
	 for (int i=0; i<str.length(); i++)
     {
       ch= str.charAt(i); //extracts each character
       strrev= ch+strrev; //adds each character in front of the existing string
     }
     System.out.println("Reversed string: "+ strrev);
   }

}
