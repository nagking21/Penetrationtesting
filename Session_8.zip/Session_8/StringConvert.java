package Session_8;

/**Write a program to convert the given string to int and given int value to string.
String str="200"; int num=30;**/


public class StringConvert {
	
	String str = "200";
	int num = 30;
	
	//Converting integer to string
	String str1 = Integer.toString(num);
		
	
	//Converting String into int using Integer.parseInt()  
		
	int i = Integer.parseInt(str);
	

}

	
	

	
	
	
	


