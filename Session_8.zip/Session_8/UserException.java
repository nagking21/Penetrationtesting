package Session_8;
/**Write a program to handle any exception and print the user-defined exception message on the console.**/

public class UserException extends Exception {
	
	public UserException(String s)
	    {
	        // Call constructor of parent Exception
	        super(s);
	    }
	// A Class that uses above MyException
	public static class Main {
	    // Driver Program
	    
		public static void main(String[] args) {
			
	        try {
	            // Throw an object of user defined exception
	            throw new UserException("user defined exception");
	        }
	        catch (UserException ex) {
	            System.out.println("Caught");
	 
	            // Print the message from MyException object
	            System.out.println(ex.getMessage());
	        }
	    }
	}
	


}
